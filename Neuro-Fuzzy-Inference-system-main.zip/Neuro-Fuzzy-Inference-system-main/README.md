 Neuro-Fuzzy-Inference-System Implementation using Python

```pip3 install anfis``` along with other dependencies like numpy, matplotlib etc.
<br>

or <br>

```python3 install setup.py```

Then cd to tests.py and
<br>

```python3 tests.py```
